package com.example.backend_Programming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendProgrammingApplicationTests {

	@Test
	void contextLoads() {
	}

}

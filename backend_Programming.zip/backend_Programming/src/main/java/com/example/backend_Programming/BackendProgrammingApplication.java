package com.example.backend_Programming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendProgrammingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendProgrammingApplication.class, args);
	}

}
